import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Graphics;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;

public class Driver extends JPanel implements ActionListener, MouseListener, WindowListener {

	public static void main(String[] args) {
		Driver d = new Driver();
	}

	static JFrame f;
	Board b;
	Timer t;
	Pawn[][] pieces = new Pawn[4][4];
	boolean firstClick = true;
	boolean whiteTurn = true;
	Pawn currP;
	CrossHair c;
	Dubs d;
	boolean pogs = false;

	public Driver() {
		f = new JFrame();
		f.setTitle("Chess");
		f.setSize(590 + 192, 613 + 192);
		f.setResizable(true);
		f.addMouseListener(this);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.add(this);
		b = new Board();
		pieces[0][3] = new Pawn(bigX(0), bigX(3), true);
		pieces[1][3] = new Pawn(bigX(1), bigX(3), true);
		pieces[2][3] = new Pawn(bigX(2), bigX(3), true);
		pieces[3][3] = new Pawn(bigX(3), bigX(3), true);

		pieces[0][0] = new Pawn(bigX(0), bigX(0), false);
		pieces[1][0] = new Pawn(bigX(1), bigX(0), false);
		pieces[2][0] = new Pawn(bigX(2), bigX(0), false);
		pieces[3][0] = new Pawn(bigX(3), bigX(0), false);
		c = new CrossHair(bigX(4), bigY(4) - 37);
		t = new Timer(16, this);
		t.start();
		f.setVisible(true);
		repaint();
	}

	@Override
	public void paint(Graphics g) {
		if (!pogs) {
			super.paintComponent(g);
			b.paint(g);
			for (Pawn[] i : pieces) {
				for (Pawn p : i) {
					if (p != null)
						p.paint(g);
				}
			}
			c.paint(g);
		} else
			d.paint(g);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		repaint();

	}

	public int bigX(int x) {
		return 192 * x;
	}

	public int smallX(int x) {
		return x / 192;
	}

	public int bigY(int y) {
		return 192 * y + 37;
	}

	public int smallY(int y) {
		return y / 192;
	}

	public int compressX(int x) {
		return (x / 192) * 192;
	}

	public int compressY(int y) {
		return ((y - 25) / 192) * 192;
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
//		System.out.println(c.getX() + " " + c.getY());
		int currX = smallX(compressX(arg0.getX()));
		int currY = smallY(compressY(arg0.getY()));
		c = new CrossHair(compressX(arg0.getX()), compressY(arg0.getY()));
//		System.out.println(c.getX() + " " + c.getY());
		if (firstClick) {
			if (whiteTurn) {
				currP = null;
				if (pieces[currX][currY] != null && pieces[currX][currY].white) {
					currP = new Pawn(pieces[currX][currY].getX(), pieces[currX][currY].getY(),
							pieces[currX][currY].white);
				}
				if (currP != null) {
					firstClick = false;
				}
			} else {
				currP = null;
				if (pieces[currX][currY] != null && !pieces[currX][currY].white) {
					currP = new Pawn(pieces[currX][currY].getX(), pieces[currX][currY].getY(),
							pieces[currX][currY].white);
				}
				if (currP != null) {
					firstClick = false;
				}
			}
		} else {
			int tempX = bigX(currX);
			int tempY = bigY(currY) - 37;
			if (isLegalMove(currP, smallX(tempX), smallY(tempY))) {
//				System.out.println(smallX(tempX) + " eggs2 " + smallY(tempY));
				pieces[smallX(tempX)][smallY(tempY)] = new Pawn(tempX, tempY, currP.white);
				pieces[smallX(currP.getX())][smallY(currP.getY())] = null;
				firstClick = true;
				currP = null;
				whiteTurn = !whiteTurn;
				for (int i = 0; i < 4; i++) {
					if (pieces[i][3] != null && !pieces[i][3].white) {
						d = new Dubs(false, false);
						pogs = true;
					} else if (pieces[i][0] != null && pieces[i][0].white) {
						d = new Dubs(true, false);
						pogs = true;
					}
				}
				boolean cring = true;
				for (Pawn[] j : pieces) {
					for (Pawn p : j) {
						if (p != null) {
							if (pieces[smallX(p.getX())][smallY(p.getY()) + (p.white ? -1 : 1)] != null) {
								if (pieces[smallX(p.getX())][smallY(p.getY())
										+ (p.white ? -1 : 1)].white != p.white) {
								} else {
									cring = false;
								}

							} else cring = false;
						}
					}
				}

				if (cring == true) {
					pogs = true;
					d = new Dubs(false, true);
				}
			} else if (endMe(smallX(tempX), smallY(tempY))) {
				if (pieces[smallX(tempX)][smallY(tempY)].white == currP.white) {
					currP.setX((tempX));
					currP.setY((tempY));
//					System.out.println(smallX(tempX) + " eggs " + smallY(tempY));
					firstClick = false;
				}
			}
		}

	}

	public boolean endMe(int x, int y) {
		return x >= 0 && y >= 0 && x <= 3 && y <= 3 && pieces[x][y] != null;
	}

	public boolean isLegalMove(Pawn p, int x, int y) {
		if (!(x >= 0 && y >= 0 && x <= 3 && y <= 3))
			return false;
		if (pieces[x][y] != null && pieces[x][y].white == p.white)
			return false;
		else if (pieces[x][y] != null)
			return Math.abs(x - smallX(p.getX())) == 1 && y - smallY(p.getY()) == (p.white ? -1 : 1);
//		System.out.println("pogs " + smallX(p.getX()) + " " + smallY(p.getY()));
		return y - smallY(p.getY()) == (p.white ? -1 : 1) && x == smallX(p.getX());
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}
}
