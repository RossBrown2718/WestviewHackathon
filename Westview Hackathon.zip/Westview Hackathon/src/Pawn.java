import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;
import java.net.URL;

public class Pawn {
	private int x;
	private int y;
	boolean white;
	Image img;
	
	public Pawn(int x, int y, boolean white) {
		this.x = x;
		this.y = y;
		this.white = white;
		img = getImage((white ? "White" : "Black") + "Pawn.png");
		init(x, y);
	}
	
	protected AffineTransform tx = AffineTransform.getTranslateInstance(this.getX(), this.getY());

	public void paint(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.drawImage(img, tx, null);
	}

	public int getY() {
		return y;
	}

	public int getX() {
		return x;
	}	

	public void setX(int x) {
		this.x = x;
	}

	public void setY(int y) {
		this.y = y;
	}

	public void init(double a, double b) {
		tx.setToTranslation(a, b);
		tx.scale(1, 1);
	}
	private Image getImage(String path) {
		Image tempImage = null;
		try {
			URL imageURL = Board.class.getResource(path);
			tempImage = Toolkit.getDefaultToolkit().getImage(imageURL);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tempImage;
	}
}
